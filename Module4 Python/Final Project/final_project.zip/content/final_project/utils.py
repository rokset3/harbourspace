import pandas as pd
import yaml
import numpy as np
from settings import BASE_PARAMS_DIR
from data_transforms import DummyTransformer

from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import SimpleImputer, KNNImputer, MissingIndicator, IterativeImputer

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, MinMaxScaler, PolynomialFeatures
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, GradientBoostingClassifier
from sklearn.decomposition import PCA 
from lightgbm import LGBMClassifier





def preprocess_data(BASE_PARAMS_DIR=BASE_PARAMS_DIR):
  
    with open(BASE_PARAMS_DIR,'r') as fd:
      cfg = yaml.safe_load(fd)
    
    feature_list = cfg.get('data')['feature_list']
    cat_cols = ['species', 'island']    #categorical columns. will drop them, if one_hot == 0, or will do one_hot encodings if one_hot == 1
    
    drop_cols = ['studyName',         #this columns will be dropped in any ways... (useless/noninformative)
                'Sample Number',
                'Region',             #single unique value for all datapoints 
                'Individual ID',
                'Comments',
                'Date Egg',
                'Stage']              #single unique value for all datapoints

    
    # preprocessing data
    data = pd.read_csv(cfg.get('data')['data_path'])
    data = data.drop(drop_cols, axis=1)             
    data.rename(columns = {'Delta 15 N (o/oo)': 'delta15n',
                          'Delta 13 C (o/oo)': 'delta13c',
                          'Culmen Length (mm)': 'culmen_len',
                          'Culmen Depth (mm)': 'culmen_dep',
                          'Flipper Length (mm)': 'flipper_len',
                          'Body Mass (g)': 'mass',
                          'Sex': 'target',}, inplace = True)

    data.columns = map(str.lower, data.columns)
    data['clutch completion'] = data['clutch completion'].map({'Yes': 1,
                                                                'No': 0})
    
    data['target'] = data['target'].map({'MALE':1,
                                        'FEMALE':0})
    #taking specified subset of features written in params.yaml
    if len(cfg.get('data')['feature_list'])>1:
      data = data[feature_list]

    #checking if we want to process categorical features
    if cfg.get('data')['one_hot'] == 1:
      one_hots = pd.get_dummies(data[cat_cols])
      data = pd.concat([data, one_hots],axis=1)
    
    data = data.drop(cat_cols, axis=1)

    if cfg.get('data')['imputer_type'] == 'No':
      data = data.dropna()
    
    data = data.dropna(subset = ['target'])

    return data

def impute_data(data, BASE_PARAMS_DIR=BASE_PARAMS_DIR):

    with open(BASE_PARAMS_DIR,'r') as fd:
        cfg = yaml.safe_load(fd)
    data = data.copy()
    cols = data.columns.values
    imp_strategy = cfg.get('data')['impute_strategy']
    imputer_type = cfg.get('data')['imputer_type']
    random_state = cfg.get('pipeline')['random_state']
    if imputer_type == 'Simple':
      imputer = SimpleImputer(missing_values=np.nan, strategy=imp_strategy)

    if imputer_type == 'Iterative':
      imputer = IterativeImputer(missing_values=np.nan, random_state=random_state)

    if imputer_type == 'KNN':
      imputer = KNNImputer()

    if imputer_type == 'No':
      imputer = DummyTransformer()

    else:
      imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
    
    data = pd.DataFrame(imputer.fit_transform(data),
                        columns = cols)
    return data

def make_pipeline(BASE_PARAMS_DIR=BASE_PARAMS_DIR):
    with open(BASE_PARAMS_DIR,'r') as fd:
        cfg = yaml.safe_load(fd)


    scaler_type = cfg.get('pipeline')['scaler_type']
    degree = cfg.get('pipeline')['n_polynomial_features']
    clf = cfg.get('pipeline')['classifier']
    n_components = cfg.get('pipeline')['n_components']
    random_state = cfg.get('pipeline')['random_state']

    
    params = cfg.get('pipeline')['params']
    params['random_state'] = random_state

    #determining scaler
    if scaler_type == 'MinMax':
      scaler = MinMaxScaler()

    if scaler_type == 'Standard':
      scaler = StandardScaler()  

    #determining polynomial degree
    if degree <2:
      polynomial_features = DummyTransformer()

    else:
      polynomial_features = PolynomialFeatures(degree=degree) 

    #determining pca
    if n_components > 0:
      pca = PCA(n_components, random_state=random_state)

    else:
      pca = DummyTransformer()



    #determining classifier
    if clf == 0:
      clf = LogisticRegression(**params)

    elif clf == 1:
      clf = DecisionTreeClassifier(**params)

    elif clf == 2:
      clf = RandomForestClassifier(**params)

    elif clf == 3:
      clf = HistGradientBoostingClassifier(**params)

    elif clf == 4:
      clf = LGBMClassifier(**params)



    pipe = Pipeline([
        ('polynomial-features', polynomial_features),
        ('scaler', scaler),
        ('pca', pca),
        ('classifier', clf),
    ])

    return pipe
