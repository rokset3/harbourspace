import pandas as pd
import yaml
import numpy as np
import joblib
import os

from settings import BASE_PARAMS_DIR, DATA_PATH, PARAMS_DIR, EXPERIMENT_DIR
from utils import preprocess_data, impute_data, make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, precision_score, recall_score, accuracy_score, adjusted_mutual_info_score, roc_auc_score, log_loss, f1_score

if __name__ == '__main__':
    with open(BASE_PARAMS_DIR,'r') as fd:
      cfg = yaml.safe_load(fd)

    if not os.path.exists(EXPERIMENT_DIR):
      os.mkdir(EXPERIMENT_DIR)

    if not os.path.exists(DATA_PATH):
      os.mkdir(DATA_PATH)

    random_state = cfg.get('pipeline')['random_state']
    test_size = cfg.get('pipeline')['test_size']

    data = preprocess_data()
    data = impute_data(data)
    pipe = make_pipeline()

    train_data, test_data = train_test_split(data, test_size=test_size)
    X_train, y_train = train_data.drop('target',axis=1), train_data.target
    X_val, y_val = test_data.drop('target',axis=1), test_data.target
    print(pipe)

    pipe.fit(X_train, y_train)
    preds = pipe.predict(X_val)
    preds_proba = pipe.predict_proba(X_val)

    metrics_dict = {
    'precision_score': float(precision_score(y_pred=preds, y_true=y_val)),
    'recall_score': float(recall_score(y_pred=preds, y_true=y_val)),
    'accuracy_score': float(accuracy_score(y_pred=preds, y_true=y_val)),
    'adjusted_mutual_info_score': float(adjusted_mutual_info_score(y_val, preds)),
    'roc_auc_score': float(roc_auc_score(y_val, preds_proba[:,1])),
    'log_loss': float(log_loss(y_val, preds_proba[:,1])),
    'f1_score': float(f1_score(y_pred=preds, y_true=y_val)),
    }
    
    with open(DATA_PATH + '/report.yaml', 'w') as f:
       yaml.dump(metrics_dict, f, default_flow_style=False)
    
    joblib.dump(pipe, DATA_PATH + '/model.pkl')

    with open(PARAMS_DIR, 'w') as f:
      documents = yaml.dump(cfg, f)

    print(f'results saved at {DATA_PATH}')

    
    

